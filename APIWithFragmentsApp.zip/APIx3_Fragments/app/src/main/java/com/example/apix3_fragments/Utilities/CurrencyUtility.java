package com.example.apix3_fragments.Utilities;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.apix3_fragments.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class CurrencyUtility extends AsyncTask<Void, Void, Void> {
    private static final String BASE_URL = "https://free.currconv.com/api/v7/convert";
    private String CURRENCY = "USD_ZAR"+","+"GBP_ZAR";
    private static final String COMPACT = "ultra";
    private static final String API_KEY = "6a63f1d0befd5e0dbb47";

    private String response;

    private View v;
    public CurrencyUtility(View v){
        this.v = v;
    }

    public URL buildURL()
    {
        URL url = null;
        Uri uriBuild = Uri.parse(BASE_URL).buildUpon()
                .appendQueryParameter("q", CURRENCY)
                .appendQueryParameter("compact", COMPACT)
                .appendQueryParameter("apiKey", API_KEY)
                .build();

        try {
            url = new URL(uriBuild.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.i("CurrencyUtil - buildURL" , ""+ url);
        return url;
    }

    public String processHttpResponse(URL u)
    {
        String response = "";
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();

            Scanner scan = new Scanner(in);
            scan.useDelimiter("//A");

            if (scan.hasNext())
            {
                response = scan.next();
            }

            urlConnection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        URL url = buildURL();
        response = processHttpResponse(url);
        Log.i("CurrencyUtil - doInBackground" , ""+ response);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid){
        super.onPostExecute(aVoid);

        double[] amount = ParseJSON();

        NumberFormat f = new DecimalFormat("#.##");

        TextView usd = v.findViewById(R.id.textView_usd);
        String temp = "$1 = R" + (f.format(amount[0]));
        usd.setText(temp);

        TextView gbp = v.findViewById(R.id.textView_gbp);
        temp = "£1 = R" + (f.format(amount[1]));
        gbp.setText(temp);
    }

    public double[] ParseJSON(){
        double[] results = new double[2];

        try{
            JSONObject apiResult = new JSONObject(response);
            results[0] = Double.parseDouble(apiResult.getString("USD_ZAR"));
            results[1] = Double.parseDouble(apiResult.getString("GBP_ZAR"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return results;
    }
}
