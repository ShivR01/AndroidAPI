package com.example.apix3_fragments.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.apix3_fragments.Models.Headline;
import com.example.apix3_fragments.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class HeadlineAdapter extends ArrayAdapter<Headline> {

    Context hContext;
    ArrayList<Headline> headlines;

    public HeadlineAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Headline> list) {
        super(context, 0, list);
        hContext = context;
        headlines = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;

        if (listItem == null)
        {
            listItem = LayoutInflater.from(hContext).inflate(R.layout.headline_list_item, parent, false);
        }

        Headline currentHeadline = headlines.get(position);

        ImageView icon = listItem.findViewById(R.id.imageView_Icon);
        String url = currentHeadline.getUrlToImage();
       if (!url.equals("null"))
       {
           if (url.substring(0,5).equals("http:")){
               url = "https" + url.substring(4);
           }
           Picasso.get()
                   .load(url)
                   .into(icon);
       }else{
           icon.setImageDrawable(getContext().getDrawable(R.drawable.noimage));
       }

        TextView title = listItem.findViewById(R.id.textView_Title);
        title.setText(currentHeadline.getTitle());

        return listItem;
    }
}
