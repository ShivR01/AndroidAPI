package com.example.apix3_fragments.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.apix3_fragments.R;
import com.example.apix3_fragments.Utilities.LocationUtility;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class SplashScreen extends AppCompatActivity {

    private static final int REQUEST_FINE_LOCATION = 0;
    public static double longitude, latitude;
    public static String city, country;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_FINE_LOCATION);
        }else{
            FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);
            client.getLastLocation()
                    .addOnCompleteListener(this, new OnCompleteListener<Location>() {
                        @Override
                        public void onComplete(@NonNull Task<Location> task) {
                            longitude = task.getResult().getLongitude();
                            latitude = task.getResult().getLatitude();
                            Log.i("SplashScreen - long: ",""+longitude);
                            Log.i("SplashScreen - lat: ",""+latitude);

                            LocationUtility lc = new LocationUtility(getApplicationContext());
                            lc.execute();
                        }
                    });
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResult){
        switch(requestCode){
            case REQUEST_FINE_LOCATION: {
                if (grantResult.length > 0 && grantResult[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
                    FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);
                    client.getLastLocation()
                            .addOnCompleteListener(this, new OnCompleteListener<Location>() {
                                @Override
                                public void onComplete(@NonNull Task<Location> task) {
                                    longitude = task.getResult().getLongitude();
                                    latitude = task.getResult().getLatitude();
                                    Log.i("SplashScreen - long: ",""+longitude);
                                    Log.i("SplashScreen - lat: ",""+latitude);

                                    LocationUtility lc = new LocationUtility(getApplicationContext());
                                    lc.execute();
                                }
                            });                    
                }else{
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
