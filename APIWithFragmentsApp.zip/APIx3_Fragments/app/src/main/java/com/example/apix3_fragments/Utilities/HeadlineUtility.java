package com.example.apix3_fragments.Utilities;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.apix3_fragments.Activities.SplashScreen;
import com.example.apix3_fragments.Adapters.HeadlineAdapter;
import com.example.apix3_fragments.Models.Headline;
import com.example.apix3_fragments.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class HeadlineUtility extends AsyncTask<Void, Void, Void> {
    private static final String BASE_URL = "https://newsapi.org/v2/";
    private static final String KEY_WORD = "top-headlines";
    private static final String COUNTRY = SplashScreen.country;
    private static final String API_KEY = "250e3bdb7e104e4296949d86d27a149a";

    private String response;

    View v;
    Context context;

    public HeadlineUtility(View v, Context c){
        this.v = v;
        this.context = c;
    }

    public URL buildURL()
    {
        URL url = null;
        Uri uriBuild = Uri.parse(BASE_URL+KEY_WORD).buildUpon()
                .appendQueryParameter("country", COUNTRY)
                .appendQueryParameter("apiKey", API_KEY)
                .build();

        try {
            url = new URL(uriBuild.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.i("NewsUtil - ParseJSON" , ""+ url);
        return url;
    }

    public String processHttpResponse(URL u)
    {
        String response = "";
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();

            Scanner scan = new Scanner(in);
            scan.useDelimiter("//A");

            if (scan.hasNext())
            {
                response = scan.next();
            }

            urlConnection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        URL url = buildURL();
        response = processHttpResponse(url);
        Log.i("NewsUtil - ParseJSON" , ""+ response);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid){
        super.onPostExecute(aVoid);

        final ArrayList<Headline> headlines = ParseJSON();

        final ListView headlineListView = v.findViewById(R.id.listView_headline);
        final HeadlineAdapter headlineAdapter = new HeadlineAdapter(v.getContext(),0, headlines);
        headlineListView.setAdapter(headlineAdapter);

        headlineListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(v.getContext(), ""+headlines.get(((int) id)).getUrl(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public ArrayList<Headline> ParseJSON()
    {
        ArrayList<Headline> headlines = new ArrayList<>();

        try {
            JSONObject apiResult = new JSONObject(response);

            JSONArray apiResultArray = apiResult.getJSONArray("articles");

            for (int i = 0; i<apiResultArray.length(); i++)
            {
                // single forecast
                JSONObject apiResultObject = apiResultArray.getJSONObject(i);

                // temp object
                Headline tempH = new Headline();

                // title
                String title = apiResultObject.getString("title");
                tempH.setTitle(title);

                // url
                String link = apiResultObject.getString("url");
                tempH.setUrl(link);

                // image
                String linkImage = apiResultObject.getString("urlToImage");
                tempH.setUrlToImage(linkImage);

                headlines.add(tempH);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return headlines;
    }

}
