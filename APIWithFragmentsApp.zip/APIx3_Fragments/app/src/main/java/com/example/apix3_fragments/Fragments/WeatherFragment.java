package com.example.apix3_fragments.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.apix3_fragments.R;
import com.example.apix3_fragments.Utilities.WeatherUtility;

public class WeatherFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.weather_fragment, container,false);
        WeatherUtility wu = new WeatherUtility(view);
        wu.execute();
        return view;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }
}
