package com.example.apix3;

import androidx.annotation.NonNull;

public class News {
    private String title;
    private String link;
    private String imageLink;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

    @NonNull
    @Override
    public String toString() {
        return this.getTitle() + " - Link: " + this.getLink() + " - Image Link: " + getImageLink();
    }
}
