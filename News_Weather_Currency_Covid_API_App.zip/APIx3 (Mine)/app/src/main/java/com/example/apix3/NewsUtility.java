package com.example.apix3;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class NewsUtility extends AsyncTask<Void, Void, Void> {
    private static final String BASE_URL = "https://newsapi.org/v2/";
    private static final String KEY_WORD = "top-headlines";
    private static final String COUNTRY = "za";
    private static final String API_KEY = "250e3bdb7e104e4296949d86d27a149a";

    private String response;

    public URL buildURL()
    {
        URL url = null;
        Uri uriBuild = Uri.parse(BASE_URL+KEY_WORD).buildUpon()
                .appendQueryParameter("country", COUNTRY)
                .appendQueryParameter("apiKey", API_KEY)
                .build();

        try {
            url = new URL(uriBuild.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.i("NewsUtil - ParseJSON" , ""+ url);
        return url;
    }

    public String processHttpResponse(URL u)
    {
        String response = "";
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();

            Scanner scan = new Scanner(in);
            scan.useDelimiter("//A");

            if (scan.hasNext())
            {
                response = scan.next();
            }

            urlConnection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        URL url = buildURL();
        response = processHttpResponse(url);
        Log.i("NewsUtil - ParseJSON" , ""+ response);
        return null;
    }

    public ArrayList<News> ParseJson()
    {
        ArrayList<News> news = new ArrayList<>();

        if (response == null)
        {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            JSONObject apiResult = new JSONObject(response);

            JSONArray apiResultArray = apiResult.getJSONArray("articles");

            for (int i = 0; i<apiResultArray.length(); i++)
            {
                // single forecast
                JSONObject apiResultObject = apiResultArray.getJSONObject(i);

                // temp object
                News tempN = new News();

                // title
                String title = apiResultObject.getString("title");
                tempN.setTitle(title);

                // url
                String link = apiResultObject.getString("url");
                tempN.setLink(link);

                // image
                String linkImage = apiResultObject.getString("urlToImage");
                tempN.setImageLink(linkImage);

                news.add(tempN);
                Log.i("NewsUtil - ParseJSON" , ""+ tempN.toString());
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return news;
    }
}
