package com.example.apix3;

import androidx.annotation.NonNull;

public class Currency {

    private String dollarToZar;

    public String getDollarToZar() {
        return dollarToZar;
    }

    public void setDollarToZar(String dollarToZar) {
        this.dollarToZar = dollarToZar;
    }

    @NonNull
    @Override
    public String toString() {
        return this.getDollarToZar() + " - Rand: " + this.getDollarToZar();
    }
}
