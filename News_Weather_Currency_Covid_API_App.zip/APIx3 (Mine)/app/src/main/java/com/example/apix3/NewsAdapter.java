package com.example.apix3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {

    Context fContext;
    ArrayList<News> news;

    public NewsAdapter(@NonNull Context context, int resource, @NonNull ArrayList<News> list) {
        super(context, 0, list);
        fContext = context;
        news = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;

        if (listItem == null)
        {
            listItem = LayoutInflater.from(fContext).inflate(R.layout.list_item, parent, false);
        }

        News currentNews = news.get(position);

        ImageView icon = listItem.findViewById(R.id.imageView_Icon);
        String url = currentNews.getImageLink();
        Picasso.get()
                .load(url)
                .into(icon);

        TextView title = listItem.findViewById(R.id.textView_Title);
        title.setText(currentNews.getTitle());

        return listItem;
    }
}
