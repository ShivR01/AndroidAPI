package com.example.apix3;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    ImageView icon;
    TextView min,max,dollar,eur,con,rec,ded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeFields();

        initializeForecasts();

        initializeCurrency();

        initializeCovid();

        NewsUtility nu = new NewsUtility();
        nu.execute();
        nu.ParseJson();
        ArrayList<News> news = nu.ParseJson();

        ListView newsListView  = findViewById(R.id.list_view);

        NewsAdapter newsAdapter = new NewsAdapter(this, 0, news);
        newsListView.setAdapter(newsAdapter);
    }

    private void initializeForecasts()
    {
        ForecastUtility fc = new ForecastUtility();
        fc.execute();
        fc.ParseJson();
        ArrayList<Forecast> forecasts = fc.ParseJson();
        Forecast currentForecast = forecasts.get(0);
        String icon0 = String.format("%02d",currentForecast.getIcon());
        String url = "https://developer.accuweather.com/sites/default/files/" +icon0 + "-s.png";
        Picasso.get()
                .load(url)
                .into(icon);
        min.setText(String.valueOf(currentForecast.getMinTemp()));
        max.setText(String.valueOf(currentForecast.getMaxTemp()));
    }

    private void initializeCurrency()
    {
        CurrencyUtility cu = new CurrencyUtility();
        cu.execute();
        cu.ParseJson();
        Currency curr = cu.ParseJson();
        dollar.setText(curr.getDollarToZar());
        eur.setText("Coming soon    ");
    }

    private void initializeCovid()
    {
        CovidUtility covidUtility = new CovidUtility();
        covidUtility.execute();
        //covidUtility.ParseJson();

        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        ArrayList<Covid> covids = covidUtility.ParseJson();

            Covid covid = covids.get(covids.size()-1);
                con.setText("Confirmed: "+String.valueOf(covid.getConfirmed()));
                rec.setText("Recovered: "+String.valueOf(covid.getRecovered()));
                ded.setText("Deaths: "+String.valueOf(covid.getDeaths()));
    }

    private void initializeFields()
    {
        icon = findViewById(R.id.imageView_Icon);
        min = findViewById(R.id.textView_Min);
        max = findViewById(R.id.textView_Max);
        dollar = findViewById(R.id.textView_dollar);
        eur = findViewById(R.id.textView_eur);
        con = findViewById(R.id.textView_Confirmed);
        rec = findViewById(R.id.textView_Recovered);
        ded = findViewById(R.id.textView_Deaths);
    }
}
