package com.example.apix3;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class CovidUtility extends AsyncTask<Void, Void, Void> {
    private static final String BASE_URL = "https://api.covid19api.com/dayone/country/south-africa";

    private String response;

    public URL buildURL()
    {
        URL url = null;
        Uri uriBuild = Uri.parse(BASE_URL).buildUpon()
                .build();

        try {
            url = new URL(uriBuild.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return url;
    }

    public String processHttpResponse(URL u)
    {
        String response = "";
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();

            Scanner scan = new Scanner(in);
            scan.useDelimiter("//A");

            if (scan.hasNext())
            {
                response = scan.next();
            }

            urlConnection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        URL url = buildURL();
        response = processHttpResponse(url);
        Log.i("CovidUtil - ParseJSON" , ""+ response);
        return null;
    }

    public ArrayList<Covid> ParseJson()
    {
        ArrayList<Covid> covids = new ArrayList<>();

        if (response == null)
        {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            JSONArray apiResultArray = new JSONArray(response);  //No need for object because it is already in array format

            for (int i = 0; i<apiResultArray.length(); i++)
            {
                // single virus
                JSONObject apiResultObject = apiResultArray.getJSONObject(i);

                // temp object
                Covid tempF = new Covid();

                String confirmed = apiResultObject.getString("Confirmed");
                tempF.setConfirmed(confirmed);

                String deaths = apiResultObject.getString("Deaths");
                tempF.setDeaths(deaths);

                String recovered = apiResultObject.getString("Recovered");
                tempF.setRecovered(recovered);

                // date
                String date = apiResultObject.getString("Date");
                tempF.setDate(date);

                covids.add(tempF);
                Log.i("CovidUtil - ParseJSON" , ""+ tempF.toString());
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return covids;
    }
}
