package com.example.apix3;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class CurrencyUtility extends AsyncTask<Void, Void, Void> {
    private static final String BASE_URL = "https://api.exchangeratesapi.io/";
    private static final String KEY_WORD = "latest";
    private static final String BASE_CURR = "USD";

    private String response;

    public URL buildURL()
    {
        URL url = null;
        Uri uriBuild = Uri.parse(BASE_URL+KEY_WORD).buildUpon()
                .appendQueryParameter("base", BASE_CURR)
                .build();

        try {
            url = new URL(uriBuild.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.i("CurrencyUtil - ParseJSON" , ""+ url);
        return url;
    }

    public String processHttpResponse(URL u)
    {
        String response = "";
        try {
            HttpURLConnection urlConnection = (HttpURLConnection) u.openConnection();
            InputStream in = urlConnection.getInputStream();

            Scanner scan = new Scanner(in);
            scan.useDelimiter("//A");

            if (scan.hasNext())
            {
                response = scan.next();
            }

            urlConnection.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        URL url = buildURL();
        response = processHttpResponse(url);
        Log.i("CuurencyUtil - ParseJSON" , ""+ response);
        return null;
    }

    public Currency ParseJson()
    {
        Currency currencies = new Currency();

        if (response == null)
        {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        try {
            JSONObject apiResult = new JSONObject(response);

            JSONObject apiResultObj = apiResult.getJSONObject("rates");

                // zar
                String zar = apiResultObj.getString("ZAR");
                currencies.setDollarToZar(zar);

                Log.i("CurrencyUtil - ParseJSON" , ""+ currencies.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return currencies;
    }
}
