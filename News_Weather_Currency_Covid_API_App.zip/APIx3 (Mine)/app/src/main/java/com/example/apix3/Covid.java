package com.example.apix3;

import androidx.annotation.NonNull;

public class Covid {

    private String confirmed;
    private String recovered;
    private String deaths;
    private String date;

    public String getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(String confirmed) {
        this.confirmed = confirmed;
    }

    public String getRecovered() {
        return recovered;
    }

    public void setRecovered(String recovered) {
        this.recovered = recovered;
    }

    public String getDeaths() {
        return deaths;
    }

    public void setDeaths(String deaths) {
        this.deaths = deaths;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @NonNull
    @Override
    public String toString() {
        return this.getDate().substring(0,10) + " - Recovered: " + this.getRecovered() + " - Confirmed: " + this.getConfirmed();
    }
}
