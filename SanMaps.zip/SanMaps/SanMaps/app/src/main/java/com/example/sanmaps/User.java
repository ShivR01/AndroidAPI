package com.example.sanmaps;

import com.google.firebase.database.Exclude;

public class User {
    public String UserName;
    public String Email;
    public String ModeTransport;
    public String Measurement;

    public User() {

    }

    public User(String userName, String email, String modeTransport, String measurement) {
        this.UserName = userName;
        this.Email = email;
        this.ModeTransport = modeTransport;
        this.Measurement = measurement;
    }

    @Exclude
    public String getUserName() {
        return UserName;
    }

    @Exclude
    public void setUserName(String userName) {
        UserName = userName;
    }

    @Exclude
    public String getEmail() {
        return Email;
    }

    @Exclude
    public void setEmail(String email) {
        Email = email;
    }
    @Exclude
    public String getModeTransport() {
        return ModeTransport;
    }
    @Exclude
    public void setModeTransport(String modeTransport) { ModeTransport = modeTransport; }

    @Exclude
    public String getMeasurement() {
        return Measurement;
    }

    @Exclude
    public void setMeasurement(String measurement) {
        Measurement = measurement;
    }

}
