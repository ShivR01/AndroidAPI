package com.example.sanmaps;

import com.google.firebase.database.Exclude;

public class Fav {
    public String Favourite;
    public String name;

    public Fav(String favourite, String name) {
        Favourite = favourite;
        this.name = name;
    }

    public Fav() {

    }

    @Exclude
    public String getName() {
        return name;
    }

    @Exclude
    public void setName(String name) {
        this.name = name;
    }

    @Exclude
    public String getFavourite() {
        return Favourite;
    }

    @Exclude
    public void setFavourite(String favourite) {
        Favourite = favourite;
    }
}
