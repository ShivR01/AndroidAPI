package com.example.sanmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.ClipData;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FavouriteActivity extends AppCompatActivity {

    ListView favouriteList;
    EditText name,address;
    Button add;
    ImageButton showAdd;
    ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        InitialiseFields();
        setVisibility();
        progressBar.setVisibility(View.VISIBLE);

        ConstraintLayout constraintLayout = findViewById(R.id.favourite);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();
        mDatabase = FirebaseDatabase.getInstance();

        DatabaseReference rootRef = mDatabase.getInstance().getReference();
        myRef = rootRef.child("Favourite");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot.child(userID));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        favouriteList.setOnItemClickListener(new AdapterView.OnItemClickListener() {  //Copying the selected address to clipboard
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText(selectedItem, selectedItem);
                    clipboard.setPrimaryClip(clip);
                    Toast.makeText(FavouriteActivity.this, "Address copied to clipboard.", Toast.LENGTH_SHORT).show();
                } else {

                }
            }
        });

    }

    private void showData(DataSnapshot dataSnapshot) {
        ArrayList<String> array = new ArrayList<>();
        for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
        {
            array.add((postSnapshot.getValue(Fav.class).getName()));
            array.add((postSnapshot.getValue(Fav.class).getFavourite()));
            array.add(" ");
        }
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,array);

        favouriteList.setAdapter(adapter);
        progressBar.setVisibility(View.GONE);

    }

    public void InitialiseFields()
    {
        favouriteList = findViewById(R.id.favouriteList);
        name = findViewById(R.id.edtName);
        address = findViewById(R.id.edtAddress);
        add = findViewById(R.id.btnAddFav);
        showAdd = findViewById(R.id.btnShowAdd);
        progressBar = findViewById(R.id.FavProgBar);
    }

    public void setVisibility()
    {
        name.setVisibility(View.INVISIBLE);
        address.setVisibility(View.INVISIBLE);
        add.setVisibility(View.INVISIBLE);
    }

    public void onShowAddClick(View view)
    {
        name.setVisibility(View.VISIBLE);
        address.setVisibility(View.VISIBLE);
        add.setVisibility(View.VISIBLE);
    }

    public void onAddClick(View view)
    {
        String edtname = name.getText().toString();
        String edtAddress = address.getText().toString();
        if (edtname.equals(null) || edtAddress.equals(null))
        {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_LONG).show();
        }else
            {
                Fav fav = new Fav(edtAddress,edtname);
                FirebaseDatabase.getInstance().getReference("Favourite").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(edtname).setValue(fav).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(FavouriteActivity.this, "Favourite place saved.", Toast.LENGTH_SHORT).show();
                        }else{
                            String message = task.getException().toString();
                        }
                    }
                });
                finish();
                startActivity(getIntent());
            }
    }
}
