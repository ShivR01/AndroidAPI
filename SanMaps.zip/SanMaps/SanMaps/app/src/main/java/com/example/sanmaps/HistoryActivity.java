package com.example.sanmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseUser currentuser;
    private DatabaseReference myRef;
    private String userID;

    private ListView historyList;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        historyList = findViewById(R.id.historyList);
        progressBar = findViewById(R.id.HistoryProgBar);
        progressBar.setVisibility(View.VISIBLE);

        ConstraintLayout constraintLayout = findViewById(R.id.history);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        userID = currentuser.getUid();
        mDatabase = FirebaseDatabase.getInstance();

        DatabaseReference rootRef = mDatabase.getInstance().getReference();
        myRef = rootRef.child("History");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //showData(dataSnapshot.child(userID).child("2020-04-01"));
                showData(dataSnapshot.child(userID));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void showData(DataSnapshot dataSnapshot) {
        ArrayList<String> array = new ArrayList<>();
        for (DataSnapshot postSnapshot : dataSnapshot.getChildren())
        {
            array.add("Date: "+(postSnapshot.getValue(History.class).getDate()));
            array.add("Address: "+(postSnapshot.getValue(History.class).getPlace()));
            array.add(" ");
        }
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,array);

        historyList.setAdapter(adapter);
        progressBar.setVisibility(View.GONE);

    }
}
