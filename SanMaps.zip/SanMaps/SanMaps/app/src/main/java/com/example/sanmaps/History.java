package com.example.sanmaps;

import com.google.firebase.database.Exclude;

public class History {
    public String Date;
    public String Place;

    public History(String date,String place) {
        this.Date = date;
        this.Place = place;
    }

    public History() {

    }

    @Exclude
    public String getDate() {
        return Date;
    }

    @Exclude
    public void setDate(String Date) {
        Date = Date;
    }

    @Exclude
    public String getPlace() {
        return Place;
    }

    @Exclude
    public void setPlace(String place) {
        Place = place;
    }
}

