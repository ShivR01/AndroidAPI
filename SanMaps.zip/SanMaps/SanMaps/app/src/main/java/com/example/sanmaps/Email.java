package com.example.sanmaps;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Email extends AppCompatActivity {
    EditText to, sub, message;
    String subject, messageDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);

        ConstraintLayout constraintLayout = findViewById(R.id.emailPage);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        subject = "SanFitness Inquiry";
        to = findViewById(R.id.toEmail);
        sub = findViewById(R.id.subject);
        message = findViewById(R.id.details);

        sub.setText(subject);

        Button buttonShare = findViewById(R.id.btnShare);
        buttonShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMail();
            }
        });
        to.setText("shivaar101@gmail.com");
    }

    private void sendMail() {
        String recipientList = to.getText().toString();
        String[] recipients = recipientList.split(",");
        messageDetails = message.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, recipients);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, messageDetails);

        intent.setType("message/rfc822");
        startActivity(Intent.createChooser(intent, "choose an email client"));

    }
}
