package com.example.sanmaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Register extends AppCompatActivity {

    private FirebaseAuth mAuth;

    private EditText user,pass,email,address;
    private Spinner modeT, measure;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        InitializeFields();
        progressBar.setVisibility(View.GONE);

        mAuth = FirebaseAuth.getInstance();
        mAuth.signOut();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mAuth.getCurrentUser() != null) {
            //startActivity(new Intent(Register.this, Home.class));
        }
    }

    public void OnRegisterClick(View view)
    {
        if ((user.getText().equals(null)) || (pass.getText().equals(null)) || (email.getText().equals(null)) || (address.getText().equals(null)))
        {
            Toast.makeText(this, "Please fill all fields.", Toast.LENGTH_SHORT).show();
        }else
            {
                createAccount();
            }
    }

    private void createAccount()
    {
        String userEmail = email.getText().toString();
        String password = pass.getText().toString();

        if (TextUtils.isEmpty(userEmail) || TextUtils.isEmpty(password) || TextUtils.isEmpty(pass.getText().toString()))
        {
            Toast.makeText(this, "Please enter all fields...", Toast.LENGTH_SHORT).show();
        }else{

            progressBar.setVisibility(View.VISIBLE);
            mAuth.createUserWithEmailAndPassword(userEmail,password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful())
                            {
                                User fbUser = new User(user.getText().toString(), email.getText().toString(), modeT.getSelectedItem().toString(), measure.getSelectedItem().toString()); //Adds new user to database
                                FirebaseDatabase database = FirebaseDatabase.getInstance();
                                DatabaseReference myRef = database.getReference("Users");
                                myRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(fbUser).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful())
                                        {
                                            Toast.makeText(Register.this, "User created successfully...", Toast.LENGTH_SHORT).show();
                                        }else{
                                            String message = task.getException().toString();
                                            Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                                Fav favourite = new Fav(address.getText().toString(),"Home");  //Adds their home address to database
                                FirebaseDatabase.getInstance().getReference("Favourite").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Home").setValue(favourite).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful())
                                        {
                                            Toast.makeText(Register.this, "Account created successfully...", Toast.LENGTH_SHORT).show();
                                        }else{
                                            String message = task.getException().toString();
                                            Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                            }else
                            {
                                String message = task.getException().toString();
                                Toast.makeText(Register.this, "Error: "+message, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    private void InitializeFields()
    {
        user = findViewById(R.id.etUsername);
        pass = findViewById(R.id.etPass);
        email = findViewById(R.id.etEmail2);
        modeT = findViewById(R.id.spinTransport);
        measure = findViewById(R.id.spinMeasure3);
        address = findViewById(R.id.etAddress);

        progressBar = findViewById(R.id.progressbar2);
    }
}
